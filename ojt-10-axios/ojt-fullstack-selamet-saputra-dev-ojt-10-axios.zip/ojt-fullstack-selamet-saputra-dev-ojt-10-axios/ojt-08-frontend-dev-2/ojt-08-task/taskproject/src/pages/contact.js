import React from "react";
// Class Components
class Contact extends React.Component {
  render() {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <h1>Contact</h1>
      </div>
    );
  }
}

export default Contact;
